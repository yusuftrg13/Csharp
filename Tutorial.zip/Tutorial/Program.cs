﻿////Değişken Tanımlama
string ad = "Ali"; //metin veri tipidir
int yas = 25; //tam sayı veri tipidir
bool isStudent = false; //mantıksal veri tipidir
float boy = 1.75f; //ondalıklı sayı veri tipidir
char cinsiyet = 'E'; //tek karakter veri tipidir

//Değişkenlerin Adlandırılması
Console.WriteLine("Adınız: " + ad);
Console.WriteLine($"Yaş:{yas}");

//Operatörler
int a = 10;
int b = 20;

int toplam = a + b; //toplam
int fark = a - b; //fark
int carpim = a * b; //çarpım
int bolum = a / b; //bölüm
int mod = a % b; //mod 

//Mantıksal Karşılaştırma Operatörleri

bool sonuc = a > b; //a, b'den büyük mü?
Console.WriteLine(sonuc); //false

sonuc = a < b; //a, b'den küçük mü? true döndürür

Console.WriteLine(sonuc); //true

sonuc = a == b; //a, b'ye eşit mi? false döndürür
Console.WriteLine(sonuc);

sonuc = a != b; //a, b'ye eşit değil mi? true döndürür

Console.WriteLine(sonuc); //true

//Mantıksal Bağlaçlar
//bool sonuc = a > b && a < 100; //a, b'den büyük ve a 100'den küçük mü?

////Kullanıcıdan Veri Alma ve Yazdırma
Console.WriteLine("Adınızı Giriniz:");
string Ad = Console.ReadLine();
Console.WriteLine("Yaşınızı Giriniz:");
int Yas = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Adınız: " + Ad);
Console.WriteLine("Yaşınız: " + Yas);

//Koşul Yapıları
int Age = 25;
if (Age >= 18)
{
    Console.WriteLine("Ehliyet alabilirsiniz.");
}
else
{
    Console.WriteLine("Ehliyet alamazsınız.");
}

////Örnek Uygulama
Console.WriteLine("Notunuzu Giriniz:");
int Not = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("2. Notunuzu Giriniz:");
int Not2 = Convert.ToInt32(Console.ReadLine());
double Ortalama = (Not + Not2) / 2;
if (Ortalama >= 50)
{
    Console.WriteLine("Geçtiniz.");
}
else
{
    Console.WriteLine("Kaldınız.");
}


//Console.Read();


////Birden fazla koşullu durum-Ehliyet Uygulaması
Console.WriteLine("*****Hoşgeldiniz*****");
Console.WriteLine("Adınızı giriniz:");
string ad = Console.ReadLine();
Console.WriteLine("Eğitim Bilgilerinizi Giriniz:");
string egitim = Console.ReadLine();
Console.WriteLine("Yaşınızı giriniz:");
int yas = Convert.ToInt32(Console.ReadLine());

if (yas >= 18 && egitim == "Lise" && egitim == "Üniversite")
{
    Console.WriteLine("Ehliyet alabilirsiniz.");
}
else if (yas >= 18 && egitim != "Lise" && egitim != "Üniversite")
{
    Console.WriteLine("Ehliyet alamazsınız.");
}
else
{
    Console.WriteLine("Ehliyet alamazsınız.");
    //}

    //For döngüsü

    //using System.Security.Cryptography;

    for (int i = 0; i < 10; i++)
{
    Console.WriteLine(i);
}

////Ters sayma
for (int i = 10; i > 0; i--)
{
    Console.WriteLine(i);
}

////Çift sayıları yazdırma
for (int i = 0; i < 100; i++)
{
    if (i % 2 == 0)
    {
        Console.WriteLine(i);
    }
}

////Tek sayıları yazdırma
for (int i = 0; i < 100; i++)
{
    if (i % 2 != 0)
    {
        Console.WriteLine(i);
    }
    //}

    //Metin dizileri ÜZERİNDE GEZİNME
    string[] meyveler = { "Elma", "Armut", "Kiraz", "Karpuz" };
for (int i = 0; i < meyveler.Length; i++)
{
    Console.WriteLine(meyveler[i]);
}

////Metin tipinde gezelim
string Names = "Gökçe Arslan";
for (int i = 0; i < Names.Length; i++)
{
    Console.WriteLine(Names[i]);
}

//While Döngüsü
int sayi = 5;
while (sayi < 10)
{
    Console.WriteLine(sayi);
    sayi++;
}

//While döngüsü kullanarak sınıftan geçti geçmedi koşulu yazdırma

//Bir öğrencinin notunu kullanıcıdan alalım
Console.WriteLine("Notunuzu Giriniz:");
int Not = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("2. Notunuzu Giriniz:");
int Not2 = Convert.ToInt32(Console.ReadLine());
double Ortalama = (Not + Not2) / 2;
while (Ortalama < 50)
{
    Console.WriteLine("Kaldınız.");
    break;

}

int sayi = 0;
while (sayi < 10000)
{
    Console.WriteLine(sayi);
    sayi++;
}

//Foreach ile Dizi Üzerinde Gezinme
string[] meyveler = { "elma", "armut", "kiraz", "karpuz" };
foreach (string meyve in meyveler)
{
    Console.WriteLine(meyve);

}

    //Metotlar
    //Metotlar, programlama dillerinde tekrar eden işlemleri tek bir yerde toplamak ve daha sonra tekrar kullanmak için kullanılır.

    //Selamlama Metodu
    static void Selamla()
{
    Console.WriteLine("Merhaba");
}
Selamla();

////Metotlara Parametre Gönderme
static void Greeting(string ad)
{
    Console.WriteLine("Merhaba " + ad);
}
Greeting("Gökçe");

////Metotlardan Değer Döndürme
static int Topla(int a, int b)
{
    return a + b;
}

////Metot Uygulaması-Not Ortalaması Kullanıcıdan bilgi almalı
static void Hesapla()
{
        Console.WriteLine("Notunuzu Giriniz:");
        int not1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("2. Notunuzu Giriniz:");
        int not2 = Convert.ToInt32(Console.ReadLine());

        double ortalama = OrtalamaHesapla(not1, not2);
        Console.WriteLine("Ortalamanız: " + ortalama);

        if (ortalama >= 50)
        {
            Console.WriteLine("Geçtiniz.");
        }
        else
        {
            Console.WriteLine("Kaldınız.");
        }
    }

    static double OrtalamaHesapla(int not1, int not2)
    {
        return (not1 + not2) / 2.0;
    }

Hesapla();
